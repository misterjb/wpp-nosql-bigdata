package com.nosql;

import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.json.JSONException;
import org.json.JSONObject;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Mongo extends JFrame {

    private JPanel contentPane;
    private JTextField txtPlz;
    private JTextField textField_1;
    private JTextArea textArea;

    private static MongoClient mongoc;
    private static MongoCollection<Document> collection;
    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        mongoc = new MongoClient();
        MongoDatabase db = mongoc.getDatabase("test");
        collection = db.getCollection("plz");
        EventQueue.invokeLater(new Runnable() {

            public void run() {
                try {
                    Mongo frame = new Mongo();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     * @throws JSONException
     */
    public Mongo() throws IOException, JSONException {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 700, 400);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        txtPlz = new JTextField();
        txtPlz.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                try {
                    textArea.append(getValue(txtPlz.getText())+"\n");
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        });
        txtPlz.setBounds(98, 11, 133, 20);
        contentPane.add(txtPlz);
        txtPlz.setColumns(10);

        textField_1 = new JTextField();
        textField_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    textArea.append(findKey(textField_1.getText())+"\n");
                } catch (JSONException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }

            }
        });
        textField_1.setBounds(98, 42, 133, 20);
        contentPane.add(textField_1);
        textField_1.setColumns(10);

        JLabel lblPlz = new JLabel("PLZ");
        lblPlz.setBounds(10, 14, 66, 14);
        contentPane.add(lblPlz);

        JLabel lblStadt = new JLabel("Stadt");
        lblStadt.setBounds(10, 45, 66, 14);
        contentPane.add(lblStadt);

        JButton btnAufgabe = new JButton("Aufgabe 7");
        btnAufgabe.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                long startTime = System.currentTimeMillis();
                try {
                    textArea.append("\n"+getValue("01001")+"\n");
                } catch (JSONException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
                try {
                    textArea.append("\n"+findKey("TUMTUM")+"\n");
                } catch (JSONException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
                try {
                    textArea.append("\n"+findKey("HAMBURG")+"\n");
                } catch (JSONException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
                long stopTime = System.currentTimeMillis();
                long elapsedTime = stopTime - startTime;
                System.out.println("Elapsed Mongo Query: " + elapsedTime);
            }
        });
        btnAufgabe.setBounds(95, 74, 136, 23);
        contentPane.add(btnAufgabe);

        textArea = new JTextArea();
        textArea.setLineWrap(true);
        textArea.setBounds(241, 9, 433, 297);
        textArea.setWrapStyleWord(true);
        contentPane.add(textArea);
        textArea.append(mongoc.getAddress()+"\n");
//        importJson();
    }
    public static void importJson() throws IOException, JSONException {
        FileReader freader = new FileReader("./res/plz.data");
        BufferedReader breader = new BufferedReader(freader);
        String dataline = breader.readLine();

        while (dataline != null )
        {
            Document data = new Document();
            JSONObject jsonObject = new JSONObject(dataline);
            for (String key : jsonObject.keySet()) {
                String val =  String.valueOf(jsonObject.get(key));
                if (key.equals("_id")) {
                    key = "id";
                }
                data.append(key, val);
            }
            collection.insertOne(data);
            dataline = breader.readLine();
        }
        breader.close();
    }

    public static String getValue(String key) throws JSONException {
        FindIterable<Document> iterator = collection.find(new Document("id", key));
        String answer = "";
        for (Document doc : iterator) {
            answer += "Ort: " + doc.get("city");
            answer += ", Bundesstaat: " + doc.get("state") + "\n";
        }
        if (answer != "") {
            return answer;
        }
        return "Keine zutreffende Eingabe!";
    }

    public static String findKey(String city) throws JSONException {
        FindIterable<Document> iterator = collection.find(new Document("city", city));
        List<String> answer = new ArrayList<>();
        for (Document doc : iterator) {
            answer.add(String.valueOf(doc.get("id")));
        }

        if (answer.isEmpty()) {
            return "Keine zutreffende Eingabe!";
        }
        return answer.toString();
    }
}
