package com.nosql;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.*;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.util.Bytes;
import org.json.JSONException;
import org.json.JSONObject;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HBase extends JFrame {

    private JPanel contentPane;
    private JTextField txtPlz;
    private JTextField textField_1;
    private JTextArea textArea;

    private static Admin hbadmin;
    private static Configuration config;
    private static TableName tableName;
    private static Connection connection;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        config = HBaseConfiguration.create();
        tableName = TableName.valueOf("PLZ");
        try {
            connection = ConnectionFactory.createConnection(config);
            System.out.println( "Connecting..." );
            hbadmin  = connection.getAdmin();
        } catch (IOException e) {
            e.printStackTrace();
        }
        EventQueue.invokeLater(new Runnable() {

            public void run() {
                try {
                    HBase frame = new HBase();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     * @throws JSONException
     */
    public HBase() throws IOException {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 700, 400);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        txtPlz = new JTextField();
        txtPlz.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                try {
                    textArea.append(getCity(txtPlz.getText())+"\n");
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        });
        txtPlz.setBounds(98, 11, 133, 20);
        contentPane.add(txtPlz);
        txtPlz.setColumns(10);

        textField_1 = new JTextField();
        textField_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    textArea.append(getPLZ(textField_1.getText())+"\n");
                } catch (IOException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }

            }
        });
        textField_1.setBounds(98, 42, 133, 20);
        contentPane.add(textField_1);
        textField_1.setColumns(10);

        JLabel lblPlz = new JLabel("PLZ");
        lblPlz.setBounds(10, 14, 66, 14);
        contentPane.add(lblPlz);

        JLabel lblStadt = new JLabel("Stadt");
        lblStadt.setBounds(10, 45, 66, 14);
        contentPane.add(lblStadt);

        JButton btnAufgabe = new JButton("Aufgabe 10");
        btnAufgabe.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                long startTime = System.currentTimeMillis();
                try {
                    textArea.append("\n"+getCity("01001")+"\n");
                } catch (IOException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
                try {
                    textArea.append("\n"+getPLZ("TUMTUM")+"\n");
                } catch (IOException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
                try {
                    textArea.append("\n"+getPLZ("HAMBURG")+"\n");
                } catch (IOException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
                long stopTime = System.currentTimeMillis();
                long elapsedTime = stopTime - startTime;
                System.out.println("Elapsed Hbase Query: " + elapsedTime);
            }
        });
        btnAufgabe.setBounds(95, 74, 136, 23);
        contentPane.add(btnAufgabe);

        textArea = new JTextArea();
        textArea.setLineWrap(true);
        textArea.setBounds(241, 9, 433, 297);
        textArea.setWrapStyleWord(true);
        contentPane.add(textArea);
        textArea.append(hbadmin.getConnection().toString() + "\n");
//        importJson();
    }
    static void importJson() throws IOException {
        HTableDescriptor htable = new HTableDescriptor(tableName);
        htable.addFamily( new HColumnDescriptor("values"));
        System.out.println( "Creating table..." );
        hbadmin.createTable(htable);
        System.out.println("Created table in HBase");

        FileReader freader = new FileReader("./res/plz.data");
        BufferedReader breader = new BufferedReader(freader);
        String dataline = breader.readLine();

        while (dataline != null) {
            JSONObject jsonObject = new JSONObject(dataline);
            String key = (String) jsonObject.get("_id");
            jsonObject.remove(key);
            addRecord(key, "values", "loc", jsonObject.get("loc").toString());
            addRecord(key, "values", "city", jsonObject.get("city").toString());
            addRecord(key, "values", "state", jsonObject.get("state").toString());
            addRecord(key, "values", "pop", jsonObject.get("pop").toString());
            dataline = breader.readLine();
        }
        breader.close();

        addColumnFamily();
    }

    static void addColumnFamily() throws IOException {
        HColumnDescriptor cd = new HColumnDescriptor("Fussball");
        hbadmin.disableTable(tableName);
        hbadmin.addColumn(tableName, cd);
        hbadmin.enableTable(tableName);

        for (String plz : getCityPLZ("HAMBURG")) {
            addRecord(plz,"Fussball","Traditionsverein","ja");
        }
    }

    static void addRecord(String rowKey,
                          String family, String qualifier, String value) throws IOException {
        Table table = connection.getTable(tableName);

        try {
            Put put = new Put(Bytes.toBytes(rowKey));
            put.addColumn(Bytes.toBytes(family), Bytes.toBytes(qualifier), Bytes.toBytes(value));
            table.put(put);
            System.out.println("inserted record " + rowKey + " to table " + tableName + " ok.");
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally
        {
            table.close();
        }
    }

    static String getCity(String rowKey) throws IOException {
        Table table = connection.getTable(tableName);
        String answer = "";

        try {
            Get get = new Get(rowKey.getBytes());
            Result res = table.get(get);

            for (Cell cell : res.listCells()) {
                String qualifier = Bytes.toString(CellUtil.cloneQualifier(cell));
                String value = Bytes.toString(CellUtil.cloneValue(cell));
                answer += "Qualifier: " + qualifier;
                answer += ", Value: " + value;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            table.close();
            if (answer != "") {
                return answer;
            }
            return "Keine zutreffende Eingabe!";
        }
    }

    public static String getPLZ(String city) throws IOException {
        List<String> plz = new ArrayList(getCityPLZ(city));
        if (plz.isEmpty()) {
            return "Keine zutreffende Eingabe!";
        }
        return plz.toString();
    }

    public static List<String> getCityPLZ(String city) throws IOException {
        Table table = connection.getTable(tableName);
        List<String> plz = new ArrayList();

        try {
            Scan s = new Scan();
            ResultScanner rs = table.getScanner(s);
            Map<String, List> map = new HashMap();
            List<String> list = new ArrayList();
            for (Result r:rs){
                byte[] value = r.getValue(Bytes.toBytes("values"), Bytes.toBytes("city"));
                if (Bytes.toString(value).equals(city)) {
                    byte[] result = r.getRow();
                    plz.add(Bytes.toString(result));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            table.close();
            return plz;
        }
    }
}
